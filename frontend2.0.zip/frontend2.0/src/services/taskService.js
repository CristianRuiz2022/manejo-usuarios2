import axios from 'axios';

const API_URL = 'http://localhost:3000/api/tasks/';

const fetchTasks = async () => {
  const response = await axios.get(API_URL, {
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`,
    },
  });
  return response.data;
};

const createTask = async (task) => {
  const response = await axios.post(API_URL, task, {
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`,
    },
  });
  return response.data;
};

const updateTask = async (id, task) => {
  const response = await axios.put(`${API_URL}${id}`, task, {
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`,
    },
  });
  return response.data;
};

const deleteTask = async (id) => {
  const response = await axios.delete(`${API_URL}${id}`, {
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`,
    },
  });
  return response.data;
};

export default {
  fetchTasks,
  createTask,
  updateTask,
  deleteTask,
};
