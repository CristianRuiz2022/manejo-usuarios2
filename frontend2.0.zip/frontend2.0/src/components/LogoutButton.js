import React from 'react';
import authService from '../services/authService';
import { notify } from './Notification';

const LogoutButton = ({ setIsLoggedIn, setUsername }) => {
  const handleLogout = () => {
    authService.logout();
    localStorage.removeItem('user');
    setIsLoggedIn(false);
    setUsername('');
    notify('Has finalizado tu sesión', 'success');
    window.location.href = '/login';
  };

  return (
    <button className="btn btn-link nav-link" onClick={handleLogout}>Salir</button>
  );
};

export default LogoutButton;
