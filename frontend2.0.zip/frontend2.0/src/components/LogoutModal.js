import React from 'react';
import { Modal, Button } from 'react-bootstrap';

const LogoutModal = ({ show, handleClose }) => {
  return (
    <Modal show={show} onHide={handleClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Sesión Cerrada</Modal.Title>
      </Modal.Header>
      <Modal.Body>Has cerrado sesión correctamente.</Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={handleClose}>
          Cerrar
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default LogoutModal;
