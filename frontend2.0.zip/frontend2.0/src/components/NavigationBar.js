import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav } from 'react-bootstrap';
import { FaUserCircle } from 'react-icons/fa';

const NavigationBar = ({ isLoggedIn, username, role, handleLogout }) => {
  return (
    <Navbar bg="light" expand="lg">
      <Navbar.Brand as={Link} to="/">Inicio</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-auto">
          {!isLoggedIn ? (
            <>
              <Nav.Link as={Link} to="/register">Registrarse</Nav.Link>
              <Nav.Link as={Link} to="/login">Iniciar Sesión</Nav.Link>
            </>
          ) : (
            <>
              {role === 'admin' && (
                <Nav.Link as={Link} to="/users">Usuarios</Nav.Link>
              )}
              <Nav.Link className="d-flex align-items-center">
                <FaUserCircle size={24} />
                <span className="ml-2">{username}</span>
              </Nav.Link>
              <Nav.Link onClick={handleLogout}>Salir</Nav.Link>
            </>
          )}
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};

export default NavigationBar;
