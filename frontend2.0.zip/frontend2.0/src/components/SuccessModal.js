import React from 'react';
import { Modal, Button } from 'react-bootstrap';
import { FaCheckCircle } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const SuccessModal = ({ show }) => {
  const navigate = useNavigate();

  const handleClose = () => {
    navigate('/welcome');
  };

  return (
    <Modal show={show} onHide={handleClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <FaCheckCircle style={{ color: 'green', marginRight: '10px' }} />
          Inicio de Sesión Exitoso
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>¡Bienvenido! Has iniciado sesión exitosamente.</p>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="success" onClick={handleClose}>
          Cerrar
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default SuccessModal;
