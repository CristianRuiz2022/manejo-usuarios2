import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const notify = (message, type) => {
  if (type === 'success') {
    toast.success(message, {
      position: "top-center",
      autoClose: 3000,
    });
  } else if (type === 'error') {
    toast.error(message, {
      position: "top-center",
      autoClose: 3000,
    });
  }
};

export { notify, ToastContainer };
