import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await axios.get('http://localhost:3000/api/users');
      setUsers(response.data);
    };
    fetchUsers();
  }, []);

  const handleDelete = async (userId) => {
    await axios.delete(`http://localhost:3000/api/users/${userId}`);
    setUsers(users.filter(user => user._id !== userId));
  };

  return (
    <div className="container mt-5">
      <h1>Administrar Usuarios</h1>
      <table className="table">
        <thead>
          <tr>
            <th>Username</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user._id}>
              <td>{user.username}</td>
              <td>{user.role}</td>
              <td>
                <button className="btn btn-danger" onClick={() => handleDelete(user._id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminDashboard;
