import React, { useEffect, useState } from 'react';
import taskService from '../services/taskService';
import TaskForm from './TaskForm';

const TaskManagement = () => {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    try {
      const data = await taskService.fetchTasks();
      setTasks(data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleCreateTask = async (task) => {
    try {
      const newTask = await taskService.createTask(task);
      setTasks([...tasks, newTask]);
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center">Task Management</h1>
      <TaskForm onCreateTask={handleCreateTask} />
      <ul className="list-group mt-3">
        {tasks.map(task => (
          <li key={task._id} className="list-group-item">
            {task.title} - {task.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskManagement;
