import React from 'react';

const AdminHome = () => {
  return (
    <div>
      <h1>Bienvenido, Administrador</h1>
      <p>Esta es la vista del administrador. Aquí puedes gestionar usuarios y realizar otras tareas administrativas.</p>
    </div>
  );
};

export default AdminHome;
