import React from 'react';

const PrivateHome = () => {
  return (
    <div>
      <h1>Panel de Administrador</h1>
      <p>Bienvenido al panel de administración. Aquí puedes gestionar usuarios y realizar otras tareas administrativas.</p>
    </div>
  );
};

export default PrivateHome;
