import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaEdit, FaTrashAlt, FaPlusCircle } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';

const Users = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/users')
      .then(response => setUsers(response.data))
      .catch(error => console.error('Error fetching users:', error));
  }, []);

  const handleDelete = (id) => {
    axios.delete(`http://localhost:3000/api/users/${id}`)
      .then(() => setUsers(users.filter(user => user._id !== id)))
      .catch(error => console.error('Error deleting user:', error));
  };

  return (
    <div className="container mt-5">
      <h2>Usuarios Registrados</h2>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Nombre de Usuario</th>
            <th>Rol</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user._id}>
              <td>{user.username}</td>
              <td>{user.role}</td>
              <td>
                <button className="btn btn-primary mr-2">
                  <FaEdit /> Editar
                </button>
                <button className="btn btn-danger" onClick={() => handleDelete(user._id)}>
                  <FaTrashAlt /> Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn btn-success">
        <FaPlusCircle /> Agregar Usuario
      </button>
    </div>
  );
};

export default Users;
