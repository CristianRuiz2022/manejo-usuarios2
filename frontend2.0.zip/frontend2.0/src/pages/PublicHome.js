import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import './PublicHome.css';
import product1 from '../images/product1.jpg';
import product2 from '../images/product2.jpg';
import product3 from '../images/product3.jpg';

const PublicHome = () => {
  return (
    <div className="container">
      <h1>Bienvenido a Amazon Lite</h1>
      <p>Explora nuestras ofertas y productos.</p>
      <Carousel>
        <Carousel.Item>
          <img
            className="d-block"
            src={product1}
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>SAMSUNG Galaxy S24, Gris Marmol, 8GB_128GB</h3>
            <p>$12,903</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block"
            src={product2}
            alt="Second slide"
          />
          <Carousel.Caption>
            <h3>ASUS Laptop TUF Gaming 2024</h3>
            <p>$12,999</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block"
            src={product3}
            alt="Third slide"
          />
          <Carousel.Caption>
            <h3>TCL Smart TV Pantalla 50" 50Q650G </h3>
            <p>$5,990</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    </div>
  );
};

export default PublicHome;
