import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Carousel from 'react-bootstrap/Carousel';
import { Container, Row, Col, Card } from 'react-bootstrap';

const Welcome = () => {
  return (
    <Container className="mt-5">
      <Row className="text-center">
        <Col>
          <h1 style={{ color: '#ff9900' }}>Bienvenido a Amazon Lite</h1>
          <p>Explora nuestras ofertas y productos.</p>
        </Col>
      </Row>
      <Row className="mt-4">
        <Col>
          <Carousel>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="/images/product1.jpg"
                alt="First slide"
              />
              <Carousel.Caption>
                <h3>SAMSUNG Galaxy S24, Gris Marmol, 8GB_128GB</h3>
                <p>$12,903</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="/images/product2.jpg"
                alt="Second slide"
              />
              <Carousel.Caption>
                <h3>Producto 2</h3>
                <p>Descripción del Producto 2</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="/images/product3.jpg"
                alt="Third slide"
              />
              <Carousel.Caption>
                <h3>Producto 3</h3>
                <p>Descripción del Producto 3</p>
              </Carousel.Caption>
            </Carousel.Item>
          </Carousel>
        </Col>
      </Row>
      <Row className="mt-5">
        <Col>
          <h2 className="text-center">Ofertas Especiales</h2>
          <Row className="mt-4">
            <Col md={4}>
              <Card>
                <Card.Img variant="top" src="/images/offer1.jpg" />
                <Card.Body>
                  <Card.Title>Oferta 1</Card.Title>
                  <Card.Text>Descripción de la Oferta 1</Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card>
                <Card.Img variant="top" src="/images/offer2.jpg" />
                <Card.Body>
                  <Card.Title>Oferta 2</Card.Title>
                  <Card.Text>Descripción de la Oferta 2</Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card>
                <Card.Img variant="top" src="/images/offer3.jpg" />
                <Card.Body>
                  <Card.Title>Oferta 3</Card.Title>
                  <Card.Text>Descripción de la Oferta 3</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </Container>
  );
};

export default Welcome;
