import React from 'react';
import { Link } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';

const Home = ({ username }) => {
  return (
    <div className="container mt-5 text-center">
      <h1 className="display-4">Bienvenido, {username}!</h1>
      <p className="lead">Esta es tu nueva pantalla de inicio después de iniciar sesión.</p>
      <div className="mt-4">
        <Link to="/tasks" className="btn btn-primary btn-lg">Gestionar Tareas</Link>
      </div>
    </div>
  );
};

export default Home;
