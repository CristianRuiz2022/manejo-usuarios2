import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Register from './pages/Register';
import Login from './pages/Login';
import PublicHome from './pages/PublicHome';
import PrivateHome from './pages/PrivateHome';
import UserManagement from './pages/UserManagement';
import NavigationBar from './components/NavigationBar';
import { notify, ToastContainer } from './components/Notification';

const PrivateRoute = ({ isLoggedIn, children }) => {
  return isLoggedIn ? children : <Navigate to="/login" />;
};

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [role, setRole] = useState('');

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      setIsLoggedIn(true);
      setUsername(user.username);
      setRole(user.role);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setIsLoggedIn(false);
    setUsername('');
    setRole('');
    notify('Has finalizado tu sesión', 'success');
  };

  return (
    <Router>
      <div>
        <NavigationBar isLoggedIn={isLoggedIn} username={username} role={role} handleLogout={handleLogout} />
        <div className="container mt-4">
          <Routes>
            <Route path="/" element={<PublicHome />} />
            <Route path="/register" element={<Register setIsLoggedIn={setIsLoggedIn} />} />
            <Route path="/login" element={<Login setIsLoggedIn={setIsLoggedIn} />} />
            <Route element={<PrivateRoute isLoggedIn={isLoggedIn} />}>
              <Route path="/welcome" element={<PrivateHome />} />
              <Route path="/users" element={<UserManagement />} />
            </Route>
          </Routes>
        </div>
        <ToastContainer />
      </div>
    </Router>
  );
};

export default App;
