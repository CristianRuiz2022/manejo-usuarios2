const User = require('../models/User');
const jwt = require('jsonwebtoken');

const registerUser = async (req, res) => {
  const { username, password } = req.body;

  console.log('Request body:', req.body); // Log para verificar los datos recibidos

  try {
    const userExists = await User.findOne({ username });

    if (userExists) {
      console.log('User already exists');
      return res.status(400).json({ message: 'User already exists' });
    }

    const user = new User({
      username,
      password,
    });

    await user.save();

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secret', {
      expiresIn: '1h',
    });

    res.status(201).json({ token });
  } catch (error) {
    console.error('Error registering user:', error); // Log para errores del servidor
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  registerUser,
};
