const express = require('express');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  try {
    const tasks = await Task.find({ user: req.user.id });
    res.json(tasks);
  } catch (error) {
    res.status(500).send('Server error');
  }
});

router.post('/', auth, async (req, res) => {
  const { title, description, dueDate, status } = req.body;
  try {
    const newTask = new Task({
      title,
      description,
      dueDate,
      status,
      user: req.user.id,
    });
    const task = await newTask.save();
    res.json(task);
  } catch (error) {
    res.status(500).send('Server error');
  }
});

module.exports = router;
